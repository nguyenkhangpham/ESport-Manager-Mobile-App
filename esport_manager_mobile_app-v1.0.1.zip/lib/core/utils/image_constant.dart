class ImageConstant {
  static String imgPostedcontenticonscomment =
      'assets/images/img_postedcontenticonscomment.svg';

  static String imgDota2iphone12promax =
      'assets/images/img_dota2iphone12promax.png';

  static String imgCrownlv50 = 'assets/images/img_crownlv50.svg';

  static String imgGroup36953Gray600 =
      'assets/images/img_group36953_gray_600.svg';

  static String imgCheckmarkPurple700 =
      'assets/images/img_checkmark_purple_700.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgImage6 = 'assets/images/img_image6.png';

  static String imgRectangle60190x341 =
      'assets/images/img_rectangle60_190x341.png';

  static String img8211364x390 = 'assets/images/img_8211_364x390.png';

  static String img0240x55 = 'assets/images/img_02_40x55.png';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgArrowleftGray100 =
      'assets/images/img_arrowleft_gray_100.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String img11 = 'assets/images/img_11.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String img20 = 'assets/images/img_20.png';

  static String imgBg = 'assets/images/img_bg.png';

  static String imgIcon64x64 = 'assets/images/img_icon_64x64.png';

  static String imgCheckmarkWhiteA700 =
      'assets/images/img_checkmark_white_a700.svg';

  static String img02 = 'assets/images/img_02.png';

  static String imgRectangle65 = 'assets/images/img_rectangle65.png';

  static String img1834x34 = 'assets/images/img_18_34x34.png';

  static String imgLolicon111x11 = 'assets/images/img_lolicon1_11x11.png';

  static String img2ir9uj4ncrhgmy4 = 'assets/images/img_2ir9uj4ncrhgmy4.png';

  static String imgMenuWhiteA700 = 'assets/images/img_menu_white_a700.svg';

  static String imgStar02 = 'assets/images/img_star02.svg';

  static String imgCsgo1 = 'assets/images/img_csgo1.png';

  static String imgLolicon1 = 'assets/images/img_lolicon1.png';

  static String img8211 = 'assets/images/img_8211.png';

  static String img12 = 'assets/images/img_12.png';

  static String imgHeart2 = 'assets/images/img_heart2.png';

  static String imgRectangle60 = 'assets/images/img_rectangle60.png';

  static String img0240x40 = 'assets/images/img_02_40x40.png';

  static String imgGroup9615 = 'assets/images/img_group9615.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String img13 = 'assets/images/img_13.png';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  static String imgBg227x382 = 'assets/images/img_bg_227x382.png';

  static String img02110x110 = 'assets/images/img_02_110x110.png';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgGroup1000000700 = 'assets/images/img_group1000000700.svg';

  static String img8211154x390 = 'assets/images/img_8211_154x390.png';

  static String imgMap = 'assets/images/img_map.svg';

  static String img2048x47 = 'assets/images/img_20_48x47.png';

  static String img1348x48 = 'assets/images/img_13_48x48.png';

  static String imgImage15 = 'assets/images/img_image15.png';

  static String imgValorant1 = 'assets/images/img_valorant1.png';

  static String imgValorantlogo3 = 'assets/images/img_valorantlogo3.png';

  static String img1248x47 = 'assets/images/img_12_48x47.png';

  static String imgCalender = 'assets/images/img_calender.png';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgRectangle601 = 'assets/images/img_rectangle60_1.png';

  static String imgGroup47 = 'assets/images/img_group47.png';

  static String imgBg1 = 'assets/images/img_bg_1.png';

  static String img18 = 'assets/images/img_18.png';

  static String imgTicket01 = 'assets/images/img_ticket01.png';

  static String imgGroup36953 = 'assets/images/img_group36953.svg';

  static String imgGroup112 = 'assets/images/img_group112.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgEkranresmi201 = 'assets/images/img_ekranresmi201.png';

  static String imgPostedcontenticonsheart =
      'assets/images/img_postedcontenticonsheart.svg';

  static String imgGroup52 = 'assets/images/img_group52.svg';

  static String imgRectangle61 = 'assets/images/img_rectangle61.svg';

  static String imgRectangle57 = 'assets/images/img_rectangle57.png';

  static String imgImage16 = 'assets/images/img_image16.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String img1848x48 = 'assets/images/img_18_48x48.png';

  static String imgIcon = 'assets/images/img_icon.png';

  static String imgGroup44 = 'assets/images/img_group44.png';

  static String img0948x48 = 'assets/images/img_09_48x48.png';

  static String imgGtavartworkf = 'assets/images/img_gtavartworkf.png';

  static String img09 = 'assets/images/img_09.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
