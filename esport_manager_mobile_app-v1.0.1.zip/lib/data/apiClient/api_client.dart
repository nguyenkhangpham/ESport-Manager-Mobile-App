import 'package:esport_manager_mobile_app/core/app_export.dart';

class ApiClient extends GetConnect {}
