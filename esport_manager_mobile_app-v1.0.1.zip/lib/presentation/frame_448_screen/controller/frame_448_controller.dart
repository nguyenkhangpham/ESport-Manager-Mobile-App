import 'package:esport_manager_mobile_app/core/app_export.dart';
import 'package:esport_manager_mobile_app/presentation/frame_448_screen/models/frame_448_model.dart';

class Frame448Controller extends GetxController {
  Rx<Frame448Model> frame448ModelObj = Frame448Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
