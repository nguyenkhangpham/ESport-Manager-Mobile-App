class Frame448Model {}
