import '../controller/frame_449_controller.dart';
import 'package:get/get.dart';

class Frame449Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => Frame449Controller());
  }
}
