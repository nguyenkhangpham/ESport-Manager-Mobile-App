import '../controller/frame_453_controller.dart';
import 'package:get/get.dart';

class Frame453Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => Frame453Controller());
  }
}
