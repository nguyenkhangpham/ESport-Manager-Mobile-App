import 'package:get/get.dart';
import 'sliderrectanglesixty_item_model.dart';

class Frame7DashboardFourModel {
  RxList<SliderrectanglesixtyItemModel> sliderrectanglesixtyItemList =
      RxList.generate(1, (index) => SliderrectanglesixtyItemModel());
}
