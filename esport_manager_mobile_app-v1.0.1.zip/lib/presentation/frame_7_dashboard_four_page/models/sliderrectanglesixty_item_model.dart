class SliderrectanglesixtyItemModel {}
