import 'package:esport_manager_mobile_app/core/app_export.dart';
import 'package:esport_manager_mobile_app/presentation/frame_7_dashboard_one_page/models/frame_7_dashboard_one_model.dart';

class Frame7DashboardOneController extends GetxController {
  Frame7DashboardOneController(this.frame7DashboardOneModelObj);

  Rx<Frame7DashboardOneModel> frame7DashboardOneModelObj;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
