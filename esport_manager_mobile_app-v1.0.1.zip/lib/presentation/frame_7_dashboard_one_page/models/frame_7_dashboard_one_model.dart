class Frame7DashboardOneModel {}
