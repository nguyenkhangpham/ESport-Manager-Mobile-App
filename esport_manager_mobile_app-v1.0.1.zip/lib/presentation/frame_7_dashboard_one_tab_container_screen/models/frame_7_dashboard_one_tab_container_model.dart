class Frame7DashboardOneTabContainerModel {}
