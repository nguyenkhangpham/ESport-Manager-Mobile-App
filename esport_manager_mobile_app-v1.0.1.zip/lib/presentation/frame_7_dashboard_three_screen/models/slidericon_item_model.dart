class SlidericonItemModel {}
