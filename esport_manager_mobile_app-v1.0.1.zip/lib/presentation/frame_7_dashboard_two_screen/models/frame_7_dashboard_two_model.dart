class Frame7DashboardTwoModel {}
