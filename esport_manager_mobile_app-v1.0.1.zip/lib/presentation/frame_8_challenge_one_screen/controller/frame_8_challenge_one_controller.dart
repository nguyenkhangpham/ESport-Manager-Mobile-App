import 'package:esport_manager_mobile_app/core/app_export.dart';
import 'package:esport_manager_mobile_app/presentation/frame_8_challenge_one_screen/models/frame_8_challenge_one_model.dart';

class Frame8ChallengeOneController extends GetxController {
  Rx<Frame8ChallengeOneModel> frame8ChallengeOneModelObj =
      Frame8ChallengeOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
