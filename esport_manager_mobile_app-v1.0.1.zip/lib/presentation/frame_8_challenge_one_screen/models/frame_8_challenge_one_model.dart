import 'package:get/get.dart';
import 'listteam_item_model.dart';

class Frame8ChallengeOneModel {
  RxList<ListteamItemModel> listteamItemList =
      RxList.generate(2, (index) => ListteamItemModel());
}
