import 'package:esport_manager_mobile_app/core/app_export.dart';
import 'package:esport_manager_mobile_app/presentation/frame_8_challenge_screen/models/frame_8_challenge_model.dart';

class Frame8ChallengeController extends GetxController {
  Rx<Frame8ChallengeModel> frame8ChallengeModelObj = Frame8ChallengeModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
