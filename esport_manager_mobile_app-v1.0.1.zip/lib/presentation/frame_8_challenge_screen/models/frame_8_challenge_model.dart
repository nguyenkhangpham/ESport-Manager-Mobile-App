class Frame8ChallengeModel {}
