import 'package:esport_manager_mobile_app/core/app_export.dart';
import 'package:esport_manager_mobile_app/presentation/profile_one_screen/models/profile_one_model.dart';

class ProfileOneController extends GetxController {
  Rx<ProfileOneModel> profileOneModelObj = ProfileOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
